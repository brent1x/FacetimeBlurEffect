//
//  AppDelegate.h
//  FacetimeStyleBlurEffect
//
//  Created by Brent Dady on 6/27/15.
//  Copyright (c) 2015 Brent Dady. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

